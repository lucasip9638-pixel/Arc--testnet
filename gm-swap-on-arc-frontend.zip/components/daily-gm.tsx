"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Flame, Share2, ExternalLink, X } from "lucide-react"

interface DailyGMProps {
  account: string | null
}

export function DailyGM({ account }: DailyGMProps) {
  const [canSayGM, setCanSayGM] = useState(true)
  const [timeUntilNext, setTimeUntilNext] = useState(0)
  const [isSending, setIsSending] = useState(false)
  const [gmSuccess, setGmSuccess] = useState(false)
  const [txHash, setTxHash] = useState<string | null>(null)

  // Mock GM stats
  const [stats, setStats] = useState({
    totalGMs: 0,
    currentStreak: 0,
    longestStreak: 0,
  })

  // Countdown timer
  useEffect(() => {
    if (timeUntilNext <= 0) {
      setCanSayGM(true)
      return
    }

    const interval = setInterval(() => {
      setTimeUntilNext((prev) => {
        if (prev <= 1) {
          setCanSayGM(true)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [timeUntilNext])

  useEffect(() => {
    if (gmSuccess) {
      const colors = ["#60A5FA", "#22D3EE", "#FFFFFF", "#34D399"]
      const confettiCount = 50

      for (let i = 0; i < confettiCount; i++) {
        const confetti = document.createElement("div")
        confetti.className = "confetti-arc"
        confetti.textContent = "ARC"
        confetti.style.left = `${Math.random() * 100}%`
        confetti.style.color = colors[Math.floor(Math.random() * colors.length)]
        confetti.style.animationDuration = `${2 + Math.random() * 2}s`
        confetti.style.animationDelay = `${Math.random() * 0.5}s`
        document.body.appendChild(confetti)

        setTimeout(() => confetti.remove(), 4000)
      }
    }
  }, [gmSuccess])

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60

    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleSayGM = async () => {
    if (!account || !canSayGM) return

    setIsSending(true)
    setGmSuccess(false)

    try {
      // Simulate GM transaction
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Mock transaction hash
      const mockTxHash = `0x${Math.random().toString(16).substring(2, 66)}`
      setTxHash(mockTxHash)

      setGmSuccess(true)
      setCanSayGM(false)
      setTimeUntilNext(86400) // 24 hours

      // Update stats
      setStats((prev) => ({
        totalGMs: prev.totalGMs + 1,
        currentStreak: prev.currentStreak + 1,
        longestStreak: Math.max(prev.currentStreak + 1, prev.longestStreak),
      }))
    } catch (error) {
      console.error("GM failed:", error)
    } finally {
      setIsSending(false)
    }
  }

  const handleShareOnX = () => {
    const text = encodeURIComponent(
      `Just said GM on-chain with @arc! 🌅\n\nCurrent streak: ${stats.currentStreak} days 🔥`,
    )
    const url = `https://twitter.com/intent/tweet?text=${text}`
    window.open(url, "_blank", "noopener,noreferrer")
  }

  const handleViewTransaction = () => {
    if (txHash) {
      window.open(`https://testnet.arcscan.app/tx/${txHash}`, "_blank", "noopener,noreferrer")
    }
  }

  const handleCloseModal = () => {
    setGmSuccess(false)
  }

  return (
    <Card className="p-6 bg-card/50 backdrop-blur-sm border-border/50">
      <h2 className="text-2xl font-bold text-foreground mb-6">Daily GM</h2>

      {/* GM Stats Grid */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-background/30 rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">Total GMs</p>
          <p className="text-xl font-bold text-foreground">{stats.totalGMs}</p>
        </div>
        <div className="bg-gradient-to-br from-accent/20 to-primary/20 rounded-lg p-3 text-center border border-accent/30">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Flame className="h-3 w-3 text-accent" />
            <p className="text-xs text-muted-foreground">Streak</p>
          </div>
          <p className="text-xl font-bold text-accent">{stats.currentStreak}</p>
        </div>
        <div className="bg-background/30 rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">Longest</p>
          <p className="text-xl font-bold text-foreground">{stats.longestStreak}</p>
        </div>
      </div>

      {/* GM Button / Countdown */}
      {!canSayGM && !gmSuccess && (
        <div className="bg-background/30 rounded-lg p-4 mb-6 text-center">
          <p className="text-sm text-muted-foreground mb-2">Next GM available in</p>
          <p className="text-2xl font-mono font-bold text-accent">{formatTime(timeUntilNext)}</p>
        </div>
      )}

      {gmSuccess && txHash && (
        <>
          {/* Backdrop overlay */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 animate-in fade-in duration-300"
            onClick={handleCloseModal}
          />

          {/* Centered floating modal */}
          <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md px-4 animate-in zoom-in-95 fade-in duration-300">
            <div className="bg-gradient-to-br from-card to-card/80 rounded-2xl p-8 border-2 border-accent/40 shadow-2xl backdrop-blur-xl relative">
              {/* Close button */}
              <button
                onClick={handleCloseModal}
                className="absolute top-4 right-4 p-2 rounded-full hover:bg-white/10 transition-colors"
              >
                <X className="h-5 w-5 text-muted-foreground hover:text-foreground" />
              </button>

              {/* Success message */}
              <div className="text-center mb-8">
                <div className="text-6xl mb-4 animate-bounce">🌅</div>
                <h3 className="text-3xl font-bold text-foreground mb-2">GM Sent!</h3>
                <p className="text-muted-foreground">Your on-chain good morning is now live</p>
              </div>

              {/* Action buttons */}
              <div className="space-y-3">
                <Button
                  onClick={handleShareOnX}
                  className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-accent to-primary hover:from-accent/90 hover:to-primary/90 gap-3"
                  size="lg"
                >
                  <Share2 className="h-6 w-6" />
                  Share on X
                </Button>
                <Button
                  onClick={handleViewTransaction}
                  variant="secondary"
                  className="w-full h-14 text-lg font-semibold gap-3 bg-white/10 hover:bg-white/20 border border-white/20"
                  size="lg"
                >
                  <ExternalLink className="h-6 w-6" />
                  View on Explorer
                </Button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Main GM Button */}
      <Button
        onClick={handleSayGM}
        disabled={!account || !canSayGM || isSending}
        className="w-full h-14 text-lg font-bold"
        size="lg"
      >
        {!account ? "Connect Wallet" : isSending ? "Sending GM..." : !canSayGM ? "GM Already Sent" : "Say GM 🌅"}
      </Button>

      {/* Info Text */}
      <p className="text-xs text-muted-foreground text-center mt-4">
        Send a daily GM on-chain to maintain your streak and earn rewards!
      </p>
    </Card>
  )
}
