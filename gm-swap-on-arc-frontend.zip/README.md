# Arc DeFi Hub

A complete DeFi platform built on Arc Network testnet featuring token swaps, staking, and daily GM rewards.

## Features

### Token Swap
- Swap between USDC and EURC on Arc Network
- 0.3% swap fee
- Real-time exchange rate calculation
- Slippage protection

### Staking
- Stake USDC tokens to earn rewards
- 10% APY (configurable)
- Real-time rewards accumulation
- Flexible stake/unstake anytime

### Daily GM
- Say "Good Morning" on-chain daily
- Build streaks for consistency
- Track your GM history
- Share on social media
- View transactions on ArcScan explorer

## Smart Contracts

The project includes three Solidity smart contracts:

1. **TokenSwap.sol** - USDC/EURC token swap with configurable fees
2. **Staking.sol** - Token staking with APY rewards
3. **DailyGM.sol** - Daily GM tracking with streak system

## Getting Started

### Prerequisites

- MetaMask or compatible Web3 wallet
- Arc Testnet configured in your wallet
- Testnet USDC for gas fees

### Arc Testnet Configuration

- Network Name: Arc Testnet
- RPC URL: https://rpc.testnet.arc.network
- Chain ID: 5042002
- Currency Symbol: USDC
- Block Explorer: https://testnet.arcscan.app

### Installation

1. Clone the repository
2. Install dependencies: `npm install`
3. Run development server: `npm run dev`
4. Open [http://localhost:3000](http://localhost:3000)

### Deploying Contracts

1. Set up Hardhat or Foundry
2. Compile the contracts in `/contracts` directory
3. Deploy to Arc testnet using the deployment script
4. Update contract addresses in `/lib/contract-config.ts`

## Tech Stack

- **Frontend**: Next.js 16, React 19, TypeScript
- **Styling**: Tailwind CSS v4
- **Smart Contracts**: Solidity 0.8.20
- **Web3**: ethers.js
- **UI Components**: shadcn/ui

## Contract Addresses

Update these in `/lib/contract-config.ts` after deployment:

- TokenSwap: `0x...`
- Staking: `0x...`
- DailyGM: `0x...`
- USDC Token: `0x...`
- EURC Token: `0x...`

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License
